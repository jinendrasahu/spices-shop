=== TM Organik ===
Contributors: ThemeMove
Requires at least: WordPress 4.0
Tested up to: WordPress 5.2.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: featured-images, post-formats, sticky-post, threaded-comments, translation-ready

== Description ==
We are glad to introduce to you TM Organik - the new released WooCommerce theme designed specially for fruits and vegetables sellers. This online shop template does not only obtain the high performance and effectiveness that an WooCommerce theme should have to attract customers. It’s better. Go exploring by yourself.

For more information about TM Organik please go to http://thememove.com.

== Changelogs ==

= 3.4.0 - June 13, 2025 =
- Updated:
WPBakery Page Builder plugin - v.8.4.1.1
WPBakery Page Builder (Visual Composer) Clipboard plugin - v.5.0.6
Revolution Slider plugin - v.6.7.34
Updated outdated templates of WooCommerce 9.9.0
- Fixed:
Fix security issue on AJAX action.

= 3.3.9 - Apr 15, 2025 =
- Updated:
WPBakery Page Builder plugin - v.8.3.1
Revolution Slider plugin - v.6.7.31

= 3.3.8 - Feb 28, 2025 =
- Updated:
Insight Core plugin v.2.7.4
Updated outdated templates of WooCommerce 9.7.0

= 3.3.7 - Feb 19, 2025 =
- Updated:
Insight Core plugin v.2.7.3
Revolution Slider plugin - v.6.7.29
- Fixed:
Fix Kirki @font-face load wrong url
Improvement customize preview loading time

= 3.3.6 - Feb 7, 2025 =
- Updated :
WPBakery Page Builder plugin - v.8.2
Revolution Slider plugin - v.6.7.28

= 3.3.5 - Jan 22, 2025 =
- Updated :
Revolution Slider plugin - v.6.7.25
WPBakery Page Builder (Visual Composer) Clipboard plugin - v.5.0.5
- Fixed :
Fix out-date WooCommerce templates v.9.6.0

= 3.3.4 - Dec 16, 2024 =
- Updated :
Insight Core plugin 2.7.1
WPBakery Page Builder plugin - v.8.1
Revolution Slider plugin - v.6.7.23
- Fixed :
Fix out-date WooCommerce templates v.9.4.0
Fix load theme text-domain

= 3.3.3 - Sep 25, 2024 =
- Fixed :
Fix out-date WooCommerce templates v.9.3.0

= 3.3.2 - Sep 9, 2024 =
- Updated :
Revolution Slider plugin - v.6.7.18
WPBakery Page Builder plugin - v.7.9

= 3.3.1 - July 31, 2024 =
- Updated :
Revolution Slider plugin - v.6.7.15
WPBakery Page Builder plugin - v.7.8

= 3.3.0 - June 20, 2024 =
- Updated :
Insight Core plugin 2.7.0
Revolution Slider plugin - v.6.7.13
WPBakery Page Builder plugin - v.7.7.2
- Fixed :
Fix out-date WooCommerce templates v.9.0.0
Fix PHP warning

= 3.2.9 - April 22, 2024 =
- Updated :
Revolution Slider plugin - v.6.7.5
- Fixed :
Fix out-date WooCommerce templates v.8.8.2

= 3.2.8 - April 12, 2024 =
- Updated :
WPBakery Page Builder plugin - v.7.6
Revolution Slider plugin - v.6.7.2

= 3.2.7 - March 18, 2024 =
- Updated :
Insight Core plugin 2.6.7
- Fixed:
Fix google font not working error.
Fix PHP warning

= 3.2.6 - Feb 28, 2024 =
- Updated :
WPBakery Page Builder plugin - v.7.5
Revolution Slider plugin - v.6.6.20
- Fixed:
Fix WooCommerce v.8.6.0 outdated template files
Fix jQuery out-date
Fix product image gallery slider not working

= 3.2.5 - Oct 17, 2023 =
- Updated :
WPBakery Page Builder plugin - v.7.1
Insight Swatches plugin - v.1.7.0
- Fixed:
Fix Custom sidebar not working on Posts

= 3.2.4 - Sep 22, 2023 =
- Fixed :
Fix Quickview does not display product images.

= 3.2.3 - Sep 21, 2023 =
- Updated :
Revolution Slider plugin - v.6.6.16
FontAwesome Pro v.5.15.4

= 3.2.2 - August 24, 2023 =
- Updated:
Insight Core plugin - v.2.6.5 (Compatible with WordPress 6.2.0)

= 3.2.1 - Aug 8, 2023 =
- Updated :
Revolution Slider plugin - v.6.6.15
WPBakery Page Builder plugin - v.7.0

= 3.2.0 - Jul 26, 2023 =
- Added :
Insight Swatches plugin - v.1.6.0 (Allows you set a style for each attribute variation as color, image, or label on product page.)
- Updated :
WPBakery Page Builder (Visual Composer) Clipboard plugin - v.5.0.4

= 3.1.9 - Jun 19, 2023 =
- Fixed :
Fix out-date WooCommerce templates v.7.8.0
Fix Cart fragments issue with WooCommerce 7.8.0

= 3.1.8 - Jun 5, 2023 =
- Updated :
Revolution Slider plugin - v.6.6.14
WPBakery Page Builder plugin - v.6.13.0

= 3.1.7 - Apr 28, 2023 =
- Updated :
Insight Core plugin - v.2.6.4
Revolution Slider plugin - v.6.6.12
WPBakery Page Builder plugin - v.6.11.0

= 3.1.6 - Feb 28, 2023 =
- Updated :
Insight Core plugin - v.2.6.3
Revolution Slider plugin - v.6.6.11
Compatible with WooCommerce 7.4.0

= 3.1.5 - Feb 06, 2023 =
- Updated :
Insight Core plugin - v.2.6.2
Revolution Slider plugin - v.6.6.10

= 3.1.4 - Dec 20, 2022 =
- Updated :
Insight Core plugin - v.2.5.1
Revolution Slider plugin - v.6.6.7
Compatible with WooCommerce 7.2.1

= 3.1.3 - Nov 07, 2022 =
- Updated :
Insight Core plugin - v.2.4.11
Revolution Slider plugin - v.6.6.5
WPBakery Page Builder plugin - v.6.10.0
- Fixed:
Tested up to Compare plugin v.3.2.0

= 3.1.2 - Oct 05, 2022 =
- Fixed :
Product Grid Load more

= 3.1.1 - Sep 27, 2022 =
- Updated :
Insight Core plugin - v.2.4.10
Revolution Slider plugin - v.6.5.31
Instagram Feed plugin - v.4.0.3

= 3.1.0 - May 12, 2022 =
- Updated :
Insight Core plugin - v.2.4.5
- Fixed:
Fix Wishlist, Compatible with WPC Smart Wishlist for WooCommerce 3.0.0

= 3.0.10 - May 10, 2022 =
- Updated :
Insight Core plugin - v.2.4.4
Revolution Slider plugin - v.6.5.21

= 3.0.9 - April 13, 2022 =
- Updated :
Insight Core plugin - v.2.4.2
Revolution Slider plugin - v.6.5.20
WPBakery Page Builder plugin - v.6.9.0
WPBakery Page Builder (Visual Composer) Clipboard plugin - v.5.0.3

= 3.0.8 - March 24, 2022 =
- Updated:
Insight Core plugin - v.2.4.0
Revolution Slider plugin - v.6.5.19
- Fixed:
Fix some style errors on mobile.

= 3.0.7 - February 09, 2022 =
- Updated:
Insight Core plugin - v.2.2.8
Revolution Slider plugin - v.6.5.15

= 3.0.6 - January 12, 2022 =
- Updated:
Revolution Slider plugin - v.6.5.14
WPBakery Page Builder plugin - v.6.8.0
WPBakery Page Builder (Visual Composer) Clipboard plugin - v.5.0.2

3.0.5 - December 06, 2021
- Updated :
Revolution Slider plugin - v.6.5.11
- Improvement:
Import Demo

3.0.4 - November 05, 2021
- Updated :
RTL Compatible

3.0.3 - October 25, 2021
- Updated :
Revolution Slider plugin - v.6.5.9
- Fixed:
Cleanup code

3.0.2 - August 27, 2021
- Updated :
Insight Core plugin - v.2.2.4
Revolution Slider plugin - v.6.5.7
WPBakery Page Builder (Visual Composer) Clipboard plugin - v.5.0.1

3.0.1 - July 31, 2021
- Updated:
Revolution Slider plugin - v.6.5.5
- Fixed:
Fix compare, compatible with WPC Smart Compare v.4.0.2

3.0.0 - July 21, 2021
- Fixed:
Fix Product Carousel Filter

2.9.9 - July 19 2021
- Updated:
Insight Core plugin v.2.2.2
Revolution Slider plugin v.6.5.4
WPBakery Page Builder plugin v.6.7.0
Update Import files

2.9.8 - June 04 2021
- Updated:
Insight Core plugin v.2.2.1
Revolution Slider plugin v.6.4.11

2.9.7 - May 11 2021
- Updated:
Insight Core plugin v.2.0.1
Revolution Slider plugin v.6.4.8
WPBakery Page Builder (Visual Composer) Clipboard plugin v.4.5.8

2.9.6 - March 10, 2021
- Updated :
Insight Core plugin - v.2.0.0
WPBakery Page Builder plugin - v.6.6.0
Revolution Slider plugin - v.6.4.2
