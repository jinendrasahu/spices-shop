<div class="entry-meta">
	<?php Insight_Templates::posted_on(); ?>
</div><!-- .entry-meta -->
