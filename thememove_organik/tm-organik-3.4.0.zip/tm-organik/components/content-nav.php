<div class="entry-nav container">
    <div class="row">
        <div
                class="col-md-5 left"><?php echo get_previous_post_link( '<i class="fas fa-angle-double-left"></i> %link' ); ?>
        </div>
        <div class="col-md-2 center">
            <i class="ion-grid"></i>
        </div>
        <div class="col-md-5 right">
			<?php echo get_next_post_link( '%link <i class="fas fa-angle-double-right"></i>' ); ?>
        </div>
    </div>
</div>