=== Insight Core ===
Contributors: thememoveclub
Donate link: https://thememove.com
Tags: insight, core, thememove
Requires at least: 5.7
Tested up to: 5.9.2
Requires PHP: 7.0
Stable tag: 2.4.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Insight Core is a core plugin for ThemeMove's themes on WordPress.org. You can check theme update, import/export demo data or customize the theme...

== Description ==

Insight Core is a core plugin for ThemeMove's themes on WordPress.org. You can check theme update, import/export demo data or customize the theme...

= Features =

- Check theme update
- Check system info
- Import/export demo data

= Need support? =

Visit [plugin documentation website](https://thememove.com "plugin documentation")

== Installation ==

1. Go to plugins in your dashboard and select "Add New"
2. Search for "Insight Core", Install & Activate it
3. Go to Insight Core menu and make your customizations

== Changelog ==

= 1.0 =
* Released

= 2.4.1 2022-04-05 =
Improvement Content Importer

= 2.4.0 2022-03-14 =
Fix security issues
