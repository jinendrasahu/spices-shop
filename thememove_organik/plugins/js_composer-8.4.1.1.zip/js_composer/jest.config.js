module.exports = {
	testMatch: [ '<rootDir>/tests/js/**/*.test.js' ],
	testEnvironment: 'jsdom'
};
