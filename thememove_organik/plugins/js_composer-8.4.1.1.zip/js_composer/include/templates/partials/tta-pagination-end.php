<?php
/**
 * Template for pagination end of Tabbed-Toggles-Accordions elements.
 *
 * @since 8.3
 * @var array $classes
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>

</ul>
