<?php
/**
 * Class that handles specific [vc_video] shortcode.
 *
 * @see js_composer/include/templates/shortcodes/vc_video.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Class WPBakeryShortCode_Vc_Video
 */
class WPBakeryShortCode_Vc_Video extends WPBakeryShortCode {
}
