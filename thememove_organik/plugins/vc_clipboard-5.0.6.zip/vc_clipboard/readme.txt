== Documentation ==
https://bitorbit.biz/wpbakery-page-builder-clipboard/documentation/